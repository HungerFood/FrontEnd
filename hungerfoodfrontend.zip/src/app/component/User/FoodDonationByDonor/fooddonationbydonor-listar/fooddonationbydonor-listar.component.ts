import { Component } from '@angular/core';

@Component({
  selector: 'app-fooddonationbydonor-listar',
  templateUrl: './fooddonationbydonor-listar.component.html',
  styleUrl: './fooddonationbydonor-listar.component.css'
})
export class FooddonationbydonorListarComponent {

}
