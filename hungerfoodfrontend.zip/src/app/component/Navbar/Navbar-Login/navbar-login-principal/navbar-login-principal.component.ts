import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar-login-principal',
  templateUrl: './navbar-login-principal.component.html',
  styleUrl: './navbar-login-principal.component.css'
})
export class NavbarLoginPrincipalComponent {

}
