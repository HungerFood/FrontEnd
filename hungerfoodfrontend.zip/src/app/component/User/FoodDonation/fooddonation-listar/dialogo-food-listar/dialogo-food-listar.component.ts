import { Component } from '@angular/core';

@Component({
  selector: 'app-dialogo-food-listar',
  templateUrl: './dialogo-food-listar.component.html',
  styleUrl: './dialogo-food-listar.component.css'
})
export class DialogoFoodListarComponent {

}
