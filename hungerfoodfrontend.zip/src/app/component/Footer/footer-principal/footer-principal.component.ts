import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-principal',
  templateUrl: './footer-principal.component.html',
  styleUrl: './footer-principal.component.css'
})
export class FooterPrincipalComponent {

}
