import { Component } from '@angular/core';

@Component({
  selector: 'app-fundadores',
  templateUrl: './fundadores.component.html',
  styleUrl: './fundadores.component.css'
})
export class FundadoresComponent {

}
