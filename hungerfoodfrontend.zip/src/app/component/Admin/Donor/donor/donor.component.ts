import { Component } from '@angular/core';

@Component({
  selector: 'app-donor',
  templateUrl: './donor.component.html',
  styleUrl: './donor.component.css'
})
export class DonorComponent {

}
