export class PaymentMethod {
    id: number;
    type: string;
}
