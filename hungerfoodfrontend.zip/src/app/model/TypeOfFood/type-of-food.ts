export class TypeOfFood {
    id: number;
    food_type_name: string;
}
