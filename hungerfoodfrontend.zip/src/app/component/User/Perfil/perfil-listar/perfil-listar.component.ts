import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-listar',
  templateUrl: './perfil-listar.component.html',
  styleUrl: './perfil-listar.component.css'
})
export class PerfilListarComponent {

}
