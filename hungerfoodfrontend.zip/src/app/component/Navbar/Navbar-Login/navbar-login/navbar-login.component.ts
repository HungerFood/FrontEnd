import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar-login',
  templateUrl: './navbar-login.component.html',
  styleUrl: './navbar-login.component.css'
})
export class NavbarLoginComponent {

}
