import { Component } from '@angular/core';

@Component({
  selector: 'app-dialogo-money-listar',
  templateUrl: './dialogo-money-listar.component.html',
  styleUrl: './dialogo-money-listar.component.css'
})
export class DialogoMoneyListarComponent {

}
