import { Component } from '@angular/core';

@Component({
  selector: 'app-fooddonationbydonor',
  templateUrl: './fooddonationbydonor.component.html',
  styleUrl: './fooddonationbydonor.component.css'
})
export class FooddonationbydonorComponent {

}
