import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar-login1',
  templateUrl: './navbar-login1.component.html',
  styleUrl: './navbar-login1.component.css'
})
export class NavbarLogin1Component {

}
