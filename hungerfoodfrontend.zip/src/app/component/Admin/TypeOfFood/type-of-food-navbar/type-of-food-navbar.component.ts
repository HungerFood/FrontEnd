import { Component } from '@angular/core';

@Component({
  selector: 'app-type-of-food-navbar',
  templateUrl: './type-of-food-navbar.component.html',
  styleUrl: './type-of-food-navbar.component.css'
})
export class TypeOfFoodNavbarComponent {

}
