import { PaymentMethod } from './../PaymentMethod/payment-method';

export class TransactionVoucher {
    id: number=0;
    total_amount:number=0.0;
    paymentmethod: PaymentMethod


}
