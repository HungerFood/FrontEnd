import { Component } from '@angular/core';

@Component({
  selector: 'app-politica-de-privacidad',
  templateUrl: './politica-de-privacidad.component.html',
  styleUrl: './politica-de-privacidad.component.css'
})
export class PoliticaDePrivacidadComponent {

}
