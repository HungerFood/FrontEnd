import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-perfil-listar-adm',
  templateUrl: './perfil-listar-adm.component.html',
  styleUrls: ['./perfil-listar-adm.component.css']
})
export class PerfilListarAdmComponent {

}