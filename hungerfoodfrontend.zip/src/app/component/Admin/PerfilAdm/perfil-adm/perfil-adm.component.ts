import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-adm',
  templateUrl: './perfil-adm.component.html',
  styleUrl: './perfil-adm.component.css'
})
export class PerfilAdmComponent {

}
