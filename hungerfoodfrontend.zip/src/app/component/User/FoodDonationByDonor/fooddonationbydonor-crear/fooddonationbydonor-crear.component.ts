import { Component } from '@angular/core';

@Component({
  selector: 'app-fooddonationbydonor-crear',
  templateUrl: './fooddonationbydonor-crear.component.html',
  styleUrl: './fooddonationbydonor-crear.component.css'
})
export class FooddonationbydonorCrearComponent {

}
