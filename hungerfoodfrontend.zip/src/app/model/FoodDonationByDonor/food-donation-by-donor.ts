export class FoodDonationByDonor {
}
