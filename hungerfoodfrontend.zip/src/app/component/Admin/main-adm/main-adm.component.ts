import { Component } from '@angular/core';

@Component({
  selector: 'app-main-adm',
  templateUrl: './main-adm.component.html',
  styleUrl: './main-adm.component.css'
})
export class MainAdmComponent {

}
