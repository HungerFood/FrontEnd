import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-KBTB5XLR.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-N66OAO6X.js";
import "./chunk-Z6KYQJGA.js";
import "./chunk-E4K7FA62.js";
import "./chunk-QCV7MVZE.js";
import "./chunk-MLG5VW3A.js";
import "./chunk-3BJMFTEP.js";
import "./chunk-PUO44O6U.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
