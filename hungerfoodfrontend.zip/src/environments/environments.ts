export const environment={
    production : false,
    //base : "http://18.216.165.101:8080/api"
    base : "http://34.205.157.28:6868/api"
    }